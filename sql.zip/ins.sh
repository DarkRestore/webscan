#!/bin/bash

# Проверяем, запущен ли скрипт с правами root
if [ "$EUID" -ne 0 ]; then
  echo "Пожалуйста, запустите скрипт с правами root (sudo)."
  exit
fi

echo "Обновление списка пакетов и системы..."
sudo apt-get update && sudo apt-get upgrade -y

echo "Установка Python и pip..."
sudo apt-get install -y python3 python3-pip screen


echo "Создание символической ссылки для python..."
if ! command -v python &> /dev/null; then
  sudo ln -s /usr/bin/python3 /usr/bin/python
  echo "Ссылка /usr/bin/python создана."
else
  echo "Символическая ссылка для python уже существует."
fi

echo "Установка необходимых библиотек Python..."
pip3 install requests tqdm telebot

echo "Установка sqlmap..."
if ! command -v sqlmap &> /dev/null; then
  echo "sqlmap не найден, начинаем установку..."
  git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git sqlmap
  ln -s "$(pwd)/sqlmap/sqlmap.py" /usr/local/bin/sqlmap
  chmod +x /usr/local/bin/sqlmap
else
  echo "sqlmap уже установлен."
fi

echo "Очистка ненужных пакетов..."
sudo apt-get autoremove -y

echo "Установка завершена!"